from flask import Flask, request, render_template, redirect, url_for
import os
from datetime import datetime

app = Flask(__name__)

if not os.path.exists('data'):
    os.makedirs('data')


@app.route('/')
def home():
    return render_template('inicio.html') 

@app.route('/inicio.html')
def inicio():
    return render_template('inicio.html')

@app.route('/historia.html')
def historia():
    return render_template('historia.html')

@app.route('/tiendas.html')
def tiendas():
    return render_template('tiendas.html')

@app.route('/productos.html')
def productos():
    return render_template('productos.html')

@app.route('/contactos.html')
def contactos_page():
    return render_template('contactos.html')

@app.route('/ordenar.html')
def ordenar_page():
    return render_template('ordenar.html')



@app.route('/submit_contact', methods=['POST'])
def submit_contact():
    if request.method == 'POST':
        nombre = request.form['nombre']
        correo = request.form['correo']
        mensaje = request.form['mensaje']

        timestamp = datetime.now().strftime("%Y%m%d_%H%M%S")
        filename = os.path.join('data', f'contacto_{timestamp}.txt')

        with open(filename, 'w') as f:
            f.write(f"Fecha/Hora: {timestamp}\n")
            f.write(f"Nombre: {nombre}\n")
            f.write(f"Correo: {correo}\n")
            f.write(f"Mensaje: {mensaje}\n")

        print(f"Contacto guardado: {filename}")
        
        return "¡Mensaje de contacto enviado con éxito! Nos pondremos en contacto contigo pronto."
    return redirect(url_for('contactos_page'))



@app.route('/submit_order', methods=['POST'])
def submit_order():
    if request.method == 'POST':
        email = request.form['email']
        direccion = request.form['direccion']
        producto = request.form['producto']
        cantidad = request.form['cantidad']
        detalles = request.form['detalles']

        timestamp = datetime.now().strftime("%Y%m%d_%H%M%S")
        filename = os.path.join('data', f'orden_{timestamp}.txt')

        with open(filename, 'w') as f:
            f.write(f"Fecha/Hora: {timestamp}\n")
            f.write(f"Email: {email}\n")
            f.write(f"Dirección: {direccion}\n")
            f.write(f"Producto: {producto}\n")
            f.write(f"Cantidad: {cantidad}\n")
            f.write(f"Detalles: {detalles}\n")

        print(f"Pedido guardado: {filename}")
    
        return "¡Tu pedido ha sido recibido con éxito! Te contactaremos para coordinar la entrega."
    return redirect(url_for('ordenar_page'))

if __name__ == '__main__':
    app.run(debug=True) 